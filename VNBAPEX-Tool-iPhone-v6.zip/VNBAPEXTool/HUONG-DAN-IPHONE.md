# VNBAPEX Tool v6 — đọc bằng chứng và mở rộng có điều kiện

Bản này mở rộng khả năng khám phá và giải thích. Chưa có bộ dữ liệu gán nhãn để đo độ chính xác hay tỷ lệ tìm “antiban”. Hàm liên quan không đồng nghĩa với hàm chống gian lận, và hàm chống gian lận không tự xác định được vị trí sửa có hiệu quả tránh ban.

## Điểm mới
- Đồ thị quan hệ gọi mở rộng 1–3 bước, chọn chiều vào/ra/cả hai. Hiện đường liên hệ, địa chỉ điểm gọi và nguồn binary hoặc dump C.
- Mẫu ARM64 dựng địa chỉ chuỗi: ADR hoặc ADRP + ADD 64-bit kề nhau trỏ đúng đầu chuỗi có dấu hiệu đã giữ.
- Điều kiện số nhóm dấu hiệu, chỉ có mẫu tham chiếu chuỗi, loại API vòng đời khỏi hiển thị/gốc mở rộng, ẩn API dùng chung và dừng mở rộng nút có quá nhiều liên kết.
- Ba ô giải thích mỗi kết quả: vai trò có thể, vì sao xuất hiện, đọc gì tiếp. Thứ tự đọc không phải phần trăm xác suất.
- Giữ nạp tệp tối đa **100 MiB = 104.857.600 byte**, dump tĩnh BIN/HEX/ASM, xuất nhiều mục và giao diện VNBAPEX Tool.

## Bắt đầu trên iPhone
1. Nạp Mach-O cùng phiên bản cần phân tích. Nếu là IPA, giải nén rồi chọn executable/framework trong đó. Dump C là nguồn bổ sung; cần đúng phiên bản.
2. Vào **Phân tích**, bắt đầu với **2 bước / cả hai chiều / ngưỡng 64**. Để các bộ lọc khác ở mặc định để quan sát toàn bộ.
3. Chọn một dòng. Đọc ba ô giải thích, bằng chứng và đường liên hệ. Phân biệt VA, RVA và file offset; chuỗi dữ liệu không phải địa chỉ hàm.
4. Muốn xem nơi có mẫu mã tham chiếu chuỗi: bật **Chỉ có mẫu tham chiếu chuỗi ARM64**. Không có kết quả chỉ có nghĩa bộ quét chưa nhận được mẫu hỗ trợ.
5. Muốn thu hẹp dấu hiệu: chọn **Ít nhất 2 nhóm**. Tên SDK và quan hệ gọi không được tính; nhóm xref là bằng chứng dựng địa chỉ, không tự chứng minh chức năng. Các nhóm là loại bằng chứng khác nhau, chưa chứng minh độc lập thống kê.
6. Nếu có nhiều API khởi tạo/pause/resume/thiết lập người dùng, thử loại API vòng đời. Bộ lọc dựa trên tên và có thể bỏ sót hàm có mã bảo mật bên trong; tắt để đối chiếu.
7. Muốn khám phá rộng: tăng lên 3 bước. Chọn không giới hạn nút chỉ khi cần kiểm tra các liên kết rộng; số kết quả có thể tăng mạnh và nhiều mục không liên quan.
8. Có thể kết hợp các điều kiện: chúng dùng phép AND. Từ khóa cách nhau bởi `|` dùng OR. **Xóa bộ lọc** trả điều kiện về mặc định.
9. Đánh dấu các mục và xuất JSON chung, gồm điều kiện, bằng chứng, VA/RVA/file offset và đường liên hệ. Danh sách chọn tối đa 5.000 mục; không chỉ trang hiện tại.

## Cách đọc kết quả
- **Có mẫu dựng địa chỉ chuỗi**: lệnh quan sát được tạo đúng địa chỉ chuỗi. Cần đọc mã dùng thanh ghi/chuỗi và nơi sử dụng kết quả để hiểu ý nghĩa.
- **Nhiều nhóm dấu hiệu**: có nhiều loại thông tin hỗ trợ đọc tiếp. Từ khóa vẫn có thể thuộc xử lý bình thường.
- **Một tên/từ khóa**: đầu mối ban đầu, không đủ kết luận.
- **Hàm liên quan N bước**: có đường trong đồ thị. Đường liên hệ không phải một chuỗi thực thi đã được chứng minh; chọn cả hai chiều có thể nối qua caller chung.
- **API dùng chung / vòng đời**: có nhiều cách giải thích; cần thân hàm và dữ liệu trước khi xác định vai trò.

Để xác minh, đối chiếu binary cùng UUID/phiên bản trong Ghidra: đọc thân hàm, caller/callee, tham chiếu và cách kết quả được sử dụng. Ghi cả bằng chứng hỗ trợ và cách giải thích khác. Không suy ra hiệu quả tránh phát hiện từ tên, số offset hay một giá trị trả về.

## Phạm vi và giới hạn
- BL trực tiếp chỉ giữ đích trùng mốc hàm metadata. Việc gán hàm chứa điểm gọi dựa trên khoảng metadata, chưa xác minh ranh giới hàm.
- Tham chiếu chuỗi chỉ xét ADR hoặc ADRP + ADD kề nhau, đúng đầu chuỗi đã giữ. Chưa có phân tích luồng dữ liệu tổng quát, BLR/con trỏ, tail-call, import stub hay XREF đầy đủ. Không truyền kết luận anticheat theo đồ thị.
- Bỏ qua quét mã được báo mã hóa. Chuỗi bị mã hóa và kiểm tra phía máy chủ không được suy ra từ quét tĩnh này.
- Giữ tối đa 100.000 quan hệ, 20.000 mẫu tham chiếu, 5.000 hàm liên quan, 16 mẫu đường/ tham chiếu cho mỗi hàm. Có chỉ báo giới hạn. Chuỗi vẫn tối đa 4.000, dài 5–4.096 ký tự ASCII/UTF-16LE Basic Latin.
- Mở rộng dừng ở nút trung gian vượt ngưỡng liên kết; hàm gốc vẫn được mở rộng. Đường ngắn nhất được giữ; không liệt kê mọi đường có thể.
- Ưu tiên đọc dựa trên quy tắc quan sát, không phải mô hình xác suất hay đánh giá độ chính xác.

## Kết quả kiểm thử
Với tệp mẫu đã cung cấp: **12.832 mục địa chỉ, 21 hàm/symbol có bằng chứng trực tiếp, 104 hàm liên quan** ở mặc định 2 bước/cả hai chiều/ngưỡng 64, **4 chuỗi và 3 mẫu dựng địa chỉ chuỗi thuộc 2 hàm**. Đây là số mục cần kiểm tra, không phải 125 hàm anticheat đã xác nhận.

Đã kiểm thử parser, quan hệ, mẫu ADR/ADRP, bộ lọc, đường liên hệ, tệp thực, nhập đúng 100 MiB và từ chối 100 MiB + 1 byte. Chromium ở 390 px và 1.240 px không có lỗi runtime hoặc tràn toàn trang trong các thao tác kiểm thử. Ảnh xem trước là Chromium, không phải iPhone thật. Chưa chạy Xcode hoặc xác nhận trên iPhone trong môi trường này.

---

## 1. Build và cập nhật app
1. Upload `VNBAPEX-Tool-iPhone-v6.zip` vào thư mục gốc repo GitHub `ipaoffset`. Giữ nguyên ZIP, không giải nén trước.
2. Lấy nội dung `VNBAPEX-build-ipa-v6.yml` kèm theo để thay file **`.github/workflows/build-ipa.yml`**. Đường dẫn workflow trong repo phải đúng như vậy, không có dấu chấm phía sau `.yml`.
3. Vào Actions → **Build VNBAPEX Tool v6** → Run workflow. Workflow giải nén, chạy test parser, tạo project bằng XcodeGen, build ARM64 và đóng gói IPA chưa ký.
4. Khi thành công, tải artifact `VNBAPEX-Tool-v6-unsigned-IPA`, giải nén để lấy IPA. Ký và cài theo phương thức bạn đã dùng cho v3.
5. Mở app và kiểm tra tiêu đề **v6.0**. Nếu còn v3.0, bạn đang dùng bản cũ. Source ZIP không phải IPA cài trực tiếp.

## 2. Chọn đúng tệp
- **Mở Mach-O iOS:** chọn binary thực thi/thư viện đã lấy ra từ IPA. Không cần đổi tên hoặc thêm phần mở rộng. Không chọn trực tiếp IPA, ZIP, APK hoặc `.so` ELF Android.
- **Mở dump C / SO.C:** chọn văn bản UTF-8 có định nghĩa hàm `sub_HEX` hoặc `FUN_HEX` và dấu ngoặc thân hàm. Khai báo, lời gọi riêng lẻ hoặc hàm đã đổi tên không có địa chỉ không đủ để tự lập bảng VA.
- **File `.asm` do app xuất không phải C.** Đọc nó bằng trình xem văn bản/công cụ phân tích; nhập lại qua nút dump C sẽ bị báo sai định dạng.
- Nếu không chọn được file qua nhà cung cấp Tệp như 3uTools, sao chép vào **Tệp → Trên iPhone → VNBAPEX Tool**, rồi chọn **Tệp trong ứng dụng → Mach-O/Dump C → tên file**. Đặt file trực tiếp trong thư mục, không đặt trong thư mục con.
- Dùng binary và dump C của cùng bản phát hành. Trùng địa chỉ không tự chứng minh cùng phiên bản. Nạp binary mới khi đã có binary trước đó sẽ bỏ dump C cũ để giảm nguy cơ trộn phiên bản.

## 3. Dump trên điện thoại
1. Nạp Mach-O; chờ thông báo thành công và danh sách section.
2. Trong **Dump mã ARM64 và dữ liệu**, chọn `__TEXT,__text` để đọc mã máy.
3. Thử **Bắt đầu trong section = `0x0`**, **Số byte = `0x100`** (256 byte), bấm **Dump ARM64 .asm** → Lưu vào Tệp.
4. Muốn xuất cả section, chọn lại section để lấy kích thước mặc định, giữ Bắt đầu = `0x0`.
5. Với `__cstring`, `__const`, `__data`, dùng HEX/BIN để xem dữ liệu. `__text` là mã, không tự đồng nghĩa anticheat; các section dữ liệu cũng không tự xác định vai trò bảo mật.
6. ASM/HEX giới hạn 64 MiB dữ liệu đầu vào mỗi lần xuất; BIN 100 MiB. Dung lượng văn bản xuất có thể lớn hơn nhiều so với byte đầu vào. Chia vùng nếu cần.

App đọc file tĩnh; không đọc bộ nhớ game khác, không giải mã FairPlay, không biến ASM thành mã giả C. Nếu cryptid khác 0, metadata vẫn có thể đọc nhưng ASM bị chặn vì vùng mã còn mã hóa.

## 4. Hiểu đúng địa chỉ
| Cột | Ý nghĩa |
|---|---|
| VA | Địa chỉ ảo trong Mach-O; với dump C đơn lẻ chỉ suy từ nhãn hàm |
| RVA (__TEXT) | VA trừ địa chỉ nền __TEXT |
| File offset | Vị trí byte tính từ đầu toàn bộ file; gồm phần dịch slice trong FAT binary |
| Slice offset | Vị trí tính từ đầu slice kiến trúc đã chọn |
| Địa chỉ chuỗi | Nơi chứa văn bản; không phải địa chỉ hàm dùng văn bản đó |

**Bắt đầu trong section** là độ lệch tính từ đầu section. Ví dụ minh họa: section bắt đầu VA `0x1000`, mục tiêu VA `0x1100` → nhập `0x100`. Đây là ví dụ số học, không phải offset của game. Chỉ áp dụng khi mục tiêu thuộc section đang chọn. Địa chỉ lúc chạy còn phụ thuộc ASLR.

## 5. Đọc bảng dấu hiệu anticheat
Bảng mục 5 được cập nhật sau khi nạp tệp; lọc theo **Hàm/symbol** hoặc **Chuỗi dữ liệu**. Chọn dòng để xem bằng chứng. Có thể xuất CSV/JSON toàn bộ dấu hiệu đang giữ, gồm địa chỉ và chú thích mức chắc chắn.

| Nhóm dấu hiệu | Ví dụ quy tắc | Cách diễn giải |
|---|---|---|
| Tên SDK/bảo mật | AnoSDK, AntiCheatExpert, anti-cheat, anti-tamper | Đầu mối về SDK/vai trò bảo mật; không chứng minh mọi hàm mang tên đó là kiểm tra gian lận |
| Tính toàn vẹn | integrity, checksum, tamper, code signature | Cần xác định dữ liệu được kiểm tra và cách dùng kết quả |
| Môi trường thiết bị | jailbreak, emulator detection | Có thể liên quan kiểm tra môi trường; cần đọc ngữ cảnh |
| Debugger | anti-debug, debugger attached | Chuỗi/tên chỉ là dấu hiệu, chưa đủ chứng minh hành vi |
| Báo cáo bảo mật | cheat report, security report | Chưa xác định nơi gửi, điều kiện gửi hay nội dung thực tế |
| API dùng chung | SHA, memcmp, sysctl, ptrace, liệt kê thư viện, đọc bộ nhớ | Bằng chứng yếu: nhiều chức năng bình thường cũng dùng các API này |

Không coi một giá trị `return -1`, `return 0`, tên `sub_...`, lời gọi mạng hoặc phép hash là bằng chứng đủ. Bộ quét bỏ comment khi xét dấu hiệu trong dump C, giữ nguyên nguồn chứng cứ và không gán chuỗi cho hàm gần nhất. Không có % “chắc chắn anticheat” hoặc danh sách “offset antiban” được tạo ra từ phỏng đoán.

## 6. Quy trình xác minh vai trò của một hàm
1. Ghi tên binary, bản phát hành, UUID và loại địa chỉ. Đối chiếu dump C với binary cùng bản.
2. Nếu dấu hiệu là chuỗi, tìm các tham chiếu đến chuỗi. App chỉ nhận một số mẫu dựng địa chỉ chuỗi ARM64; chưa phân tích XREF đầy đủ; chưa thể kết luận hàm nào sử dụng chuỗi chỉ từ bảng này.
3. Nếu dấu hiệu là hàm, đọc tham số, dữ liệu đầu vào, nhánh điều kiện, lời gọi và kết quả trả về. Bản xem trước có thể bị rút gọn, cần đối chiếu dump gốc.
4. Theo dõi nơi dùng kết quả: ghi log, xử lý lỗi, xác thực dữ liệu hay quyết định bảo mật? Giữ các giải thích thay thế, ví dụ kiểm tra checksum để xác minh tải file chứ không kiểm tra gian lận.
5. Chỉ mô tả vai trò có bằng chứng. Mẫu ghi chép: **giả thuyết → đoạn mã/chuỗi hỗ trợ → hàm gọi/được gọi → giải thích khác → điểm chưa xác minh**.
6. Không có kết quả không chứng minh không có anticheat: symbol có thể bị xóa, chuỗi mã hóa, hoặc logic nằm ở binary khác/phía máy chủ.

## 7. Làm tiếp trên Windows bằng Ghidra
1. Tải bản phát hành chính thức, cài Java theo hướng dẫn đi kèm đúng phiên bản và chạy `ghidraRun.bat`.
2. Tạo project local; import chính Mach-O đã phân tích; mở CodeBrowser và chạy phân tích tự động.
3. Đối chiếu địa chỉ nền/section. Dùng Go To với **VA** của mục tiêu. Không mặc định file offset là VA; nếu project đã rebase cần điều chỉnh theo địa chỉ nền mới.
4. Với chuỗi, xem References/XREF. Với hàm, xem Listing, Decompiler và các hàm gọi/được gọi.
5. Xác minh ý nghĩa theo quy trình mục 6. Mã decompiler là kết quả suy luận, không phải mã nguồn gốc; tên/kiểu có thể cần chỉnh sau phân tích.

Nguồn tham khảo chính thức:
- Ghidra và hướng dẫn cài: https://github.com/NationalSecurityAgency/ghidra
- Định dạng Mach-O: https://github.com/apple-oss-distributions/xnu/blob/main/EXTERNAL_HEADERS/mach-o/loader.h

## 8. Giới hạn kỹ thuật minh bạch
- Giới hạn nhập là 100 MiB mỗi tệp, không phải cam kết iOS luôn cấp đủ bộ nhớ. Mach-O vẫn cần một buffer đầu vào để đọc metadata; buffer được bỏ sau phân tích, model không giữ nó qua closure.
- Dump C đọc từng phần, không tạo chuỗi 100 MiB rồi nhân bản để mask comment. Giữ tối đa 100.000 hàm; vượt mức này báo lỗi và yêu cầu chia file.
- Bản xem trước: tối đa 32.768 ký tự/hàm, tổng 8.388.608 ký tự. Khi hết ngân sách, vẫn đọc tiếp và xét quy tắc dấu hiệu, nhưng không giữ toàn bộ thân hàm để hiển thị/xuất.
- Giữ tối đa 256 tên lời gọi/hàm và 24 bằng chứng đã khử trùng lặp/hàm. Chuỗi literal chỉ xét 4.096 ký tự đầu. Bộ đọc không phải trình biên dịch C/C++ đầy đủ.
- Quét binary xét chuỗi ASCII hoặc UTF-16LE Basic Latin in được, kết thúc NUL, dài 5–4.096 ký tự; giữ tối đa 4.000 chuỗi trùng quy tắc. Không quét đầy đủ Unicode UTF-16 hoặc giải mã chuỗi bị mã hóa. Nếu đạt giới hạn, giao diện ghi rõ.
- Metadata không bảo đảm liệt kê mọi hàm. Symbol có thể là nhãn. Giới hạn bảo vệ: 16.384 load command, 2.000.000 symbol và 100.000 mục hàm.
- CSV danh sách địa chỉ vẫn chứa các mục được parser giữ. JSON và phần đọc hàm chỉ có **bản xem trước** khi bị rút gọn, không thể dùng thay bản dump C gốc.
- Tên “image” đã đổi thành Tên file thực thi/thư viện lúc chạy, chỉ dùng khi sinh mã. Không cần điền để dump. ABI phải được xác minh; không điền số lượng tham số như `1` vào ô kiểu tham số.

## 9. Khi có lỗi
Dùng **Xuất nhật ký lỗi** và gửi cùng phiên bản app, dung lượng, loại file, thao tác gây lỗi. Lỗi 16 MiB nghĩa là vẫn đang chạy bản cũ. Nếu WebContent đóng, app báo chưa xác định nguyên nhân và yêu cầu nạp lại, không tự kết luận thiếu RAM. Phiên chưa được tự khôi phục.

## 10. Đã kiểm tra và chưa kiểm tra
Đã kiểm tra trên Linux/Node/JSDOM: nhập Mach-O 100 MiB, dump C 100 MiB theo từng phần, từ chối 100 MiB + 1 byte; các ranh giới chunk/UTF-8; phân trang, lọc, chọn dòng, trạng thái bận/reset; bằng chứng ngoài phần thân được giữ; bỏ comment; phân biệt ASM/C; địa chỉ chuỗi đối chiếu byte gốc; không đổi kết quả offset/CSV/khung mã của bộ kiểm tra cũ.

Tệp Mach-O thực tế đã đọc 12.832 mục địa chỉ. Tệp thử 100 MiB Mach-O là bản đệm thêm byte để kiểm tra dung lượng, không đại diện cho mọi binary phức tạp 100 MiB. Dump C thử 100 MiB chứa padding và hàm hợp lệ để kiểm tra đọc hết tệp, không đại diện cho mọi cấu trúc C/C++.

Chưa build bằng Xcode hoặc chạy UIKit/WebKit trên iPhone trong môi trường hiện tại. Workflow sẽ build thực tế trên macOS khi bạn chạy Actions. Chi tiết kiểm tra nằm trong `VALIDATION.json`; test parser và quan hệ trong thư mục `Tests`.

Bổ sung kiểm tra v6: Chromium ở kích thước điện thoại 390 px và desktop 1.240 px; nhập tệp thực, lọc quan hệ, tìm nhiều từ khóa và xuất nhiều mục đã qua. Ảnh xem trước được chụp từ giao diện chạy trong Chromium, không phải ảnh chạy trên iPhone thật.
