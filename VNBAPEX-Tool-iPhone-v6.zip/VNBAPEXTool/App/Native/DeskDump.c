#define _POSIX_C_SOURCE 200809L
#include "DeskDump.h"
#include <capstone/capstone.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <limits.h>

const char *desk_dump_error(int code) {
    switch(code) {
        case 0: return "OK";
        case 1: return "Invalid range, alignment or mode";
        case 2: return "Cannot open input file";
        case 3: return "Cannot create output file";
        case 4: return "Range is outside input file";
        case 5: return "Input read failed";
        case 6: return "Output write failed";
        case 7: return "Capstone initialization failed";
        default: return "Unknown dump error";
    }
}

int desk_dump_range(const char *input_path, const char *output_path,
                    uint64_t offset, uint64_t va, uint64_t length,
                    int mode, DeskDumpStats *stats) {
    if (stats) *stats = (DeskDumpStats){0,0,0};
    if (!input_path || !output_path || !length || mode < 0 || mode > 2 ||
        offset > INT64_MAX || length > INT64_MAX-offset || length > UINT64_MAX-va ||
        (mode == 2 && (va & 3))) return 1;
    FILE *in = fopen(input_path, "rb");
    if (!in) return 2;
    if (fseeko(in,0,SEEK_END) != 0) { fclose(in); return 4; }
    off_t end = ftello(in);
    if (end < 0 || offset+length > (uint64_t)end || fseeko(in,(off_t)offset,SEEK_SET) != 0) { fclose(in); return 4; }
    csh handle = 0; cs_insn *insn = NULL;
    if (mode == 2) {
        if (cs_open(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN, &handle) != CS_ERR_OK) { fclose(in); return 7; }
        insn = cs_malloc(handle);
        if (!insn) { cs_close(&handle); fclose(in); return 7; }
    }
    FILE *out = fopen(output_path,"wb");
    if (!out) { if(insn)cs_free(insn,1);if(handle)cs_close(&handle);fclose(in);return 3; }
    if (mode) fprintf(out,"; VNBAPEX Tool — static file dump\n; file_offset=0x%" PRIX64 " va=0x%" PRIX64 " length=0x%" PRIX64 "\n; .word/.byte = unknown instruction or data. Not C pseudocode.\n\n",offset,va,length);
    uint8_t buf[65536];uint64_t done=0;int result=0;
    while (done < length) {
        size_t n=(length-done > sizeof(buf))?sizeof(buf):(size_t)(length-done);
        if (fread(buf,1,n,in)!=n) { result=5;break; }
        if (mode==0) { if(fwrite(buf,1,n,out)!=n){result=6;break;} }
        else if (mode==1) {
            for(size_t j=0;j<n;j+=16) {
                fprintf(out,"file:%012" PRIX64 " va:%016" PRIX64 "  ",offset+done+j,va+done+j);
                for(size_t k=0;k<16;k++){if(j+k<n)fprintf(out,"%02X ",buf[j+k]);else fputs("   ",out);}
                fputs(" |",out);for(size_t k=0;k<16&&j+k<n;k++){int c=buf[j+k];fputc(c>=32&&c<=126?c:'.',out);}fputs("|\n",out);
            }
        } else {
            for(size_t j=0;j<n;) {
                if(n-j<4) {
                    fprintf(out,"%016" PRIX64 "  %02X        .byte 0x%02X\n",va+done+j,buf[j],buf[j]);j++;if(stats)stats->unknown++;continue;
                }
                const uint8_t *ptr=buf+j;size_t remaining=4;uint64_t address=va+done+j;
                fprintf(out,"%016" PRIX64 "  %02X%02X%02X%02X  ",address,buf[j],buf[j+1],buf[j+2],buf[j+3]);
                if(cs_disasm_iter(handle,&ptr,&remaining,&address,insn) && insn->size==4) {
                    fprintf(out,"%-9s %s\n",insn->mnemonic,insn->op_str);if(stats)stats->decoded++;
                } else {
                    uint32_t word=(uint32_t)buf[j]|((uint32_t)buf[j+1]<<8)|((uint32_t)buf[j+2]<<16)|((uint32_t)buf[j+3]<<24);
                    fprintf(out,".word 0x%08" PRIX32 "\n",word);if(stats)stats->unknown++;
                }
                j+=4;
            }
        }
        if(ferror(out)){result=6;break;}done+=n;if(stats)stats->input_bytes=done;
    }
    if(fclose(out)!=0)result=6;fclose(in);if(insn)cs_free(insn,1);if(handle)cs_close(&handle);
    if(result)remove(output_path);
    return result;
}
