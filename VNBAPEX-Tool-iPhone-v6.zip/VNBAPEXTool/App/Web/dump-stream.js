/* Incremental UTF-8 C-dump reader; keeps bounded previews and scans the full input.
   Addresses are labels, not verified live addresses. */
(function(root){
'use strict';
function create(){
 const E=root.OffsetEvidence,rows=[],maxRows=100000,perBody=32768,totalBudget=8*1024*1024;
 let budget=totalBudget,state='code',slash=false,star=false,escape=false,depth=0,head='',literal='',quote='',line=1,active=null,token='',pendingCall='',skippedBodies=0,totalChars=0,asmLines=0,linePrefix='';
 function evidence(items){if(active)active.evidence=E.unique([...active.evidence,...items]);}
 function identifier(){if(token){pendingCall=token;token='';}}
 function normal(c){
  if(depth===0){
   if(c==='{'){
    const m=/\b((?:sub_|FUN_)[0-9a-fA-F]+)\s*\([^;{}]*\)\s*$/.exec(head);
    if(m){if(rows.length>=maxRows)throw Error('Dump vượt 100.000 hàm; chia file để phân tích.');active={name:m[1],va:BigInt('0x'+m[1].replace(/^(sub_|FUN_)/,'')),base:null,rva:null,fileOffset:null,sliceOffset:null,sources:['C dump: địa chỉ suy từ tên, chưa xác minh'],body:'',previewParts:[],previewLength:0,signature:head.trim().slice(-4096),calls:[],evidence:[],dumpLine:line,bodyTruncated:false,callsTruncated:false};capture('{');}
    depth=1;head='';token='';pendingCall='';
   }else if(c===';'||c==='}')head='';else {head+=c;if(head.length>16384)head=head.slice(-8192);}
   return;
  }
  if(/[A-Za-z0-9_$]/.test(c)){token+=c;if(token.length>256)token=token.slice(-256);}
  else {identifier();if(c==='('&&pendingCall){if(!['if','for','while','switch','sizeof','return'].includes(pendingCall)){
   evidence(E.callEvidence(pendingCall));evidence(E.textEvidence(pendingCall,'Tên lời gọi trong dump C'));
   if(active&&!active.calls.includes(pendingCall)){if(active.calls.length<256)active.calls.push(pendingCall);else active.callsTruncated=true;}
  }pendingCall='';}else if(!/\s/.test(c))pendingCall='';}
  if(c==='{')depth++;
  if(c==='}'&&--depth===0){if(active){active.body=active.previewParts.join('');delete active.previewParts;delete active.previewLength;if(active.bodyTruncated)skippedBodies++;rows.push(active);}active=null;head='';token='';pendingCall='';}
 }
 function capture(c){if(active){if(active.previewLength+c.length<=perBody&&budget>=c.length){active.previewParts.push(c);active.previewLength+=c.length;budget-=c.length;}else active.bodyTruncated=true;}}
 function code(c){
  if(slash){slash=false;if(c==='/'){state='line';return;}if(c==='*'){state='block';star=false;return;}normal('/');}
  if(c==='/'){slash=true;return;}
  if(c==='"'||c==="'"){identifier();state='literal';quote=c;literal='';escape=false;if(depth===0)head+=' ';return;}
  normal(c);
 }
 return {
  push(text){totalChars+=text.length;for(const c of text){
   capture(c);
   if(c==='\n'){if(/^[0-9A-Fa-f]{8,16}\s+[0-9A-Fa-f]{8}\s+\S/.test(linePrefix))asmLines++;linePrefix='';line++;}else if(linePrefix.length<100)linePrefix+=c;
   if(state==='line'){if(c==='\n'){state='code';if(depth===0)head+='\n';}continue;}
   if(state==='block'){if(star&&c==='/'){state='code';star=false;if(depth===0)head+=' ';}else star=c==='*';continue;}
   if(state==='literal'){if(escape){escape=false;if(literal.length<4096)literal+=c;continue;}if(c==='\\'){escape=true;continue;}if(c===quote){evidence(E.textEvidence(literal,'Chuỗi trong thân hàm dump C'));state='code';}else if(literal.length<4096)literal+=c;continue;}
   code(c);
  }},
  finish(){if(active||state==='block'||state==='literal')throw Error('Dump C kết thúc giữa hàm/chuỗi/comment; file có thể bị cắt ngắn.');if(!rows.length)throw Error(asmLines?'Đây là dump ASM, không phải C. ASM do app xuất dùng để đọc lệnh; không nhập qua nút dump C.':'Không thấy định nghĩa sub_HEX/FUN_HEX. Dump phải có thân hàm C và nhãn địa chỉ.');return {rows,stats:{functions:rows.length,previewCharacters:totalBudget-budget,truncatedPreviews:skippedBodies,charactersRead:totalChars,maxRows,perBody,totalBudget}};}
 };
}
const api={create};root.OffsetDumpStream=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
