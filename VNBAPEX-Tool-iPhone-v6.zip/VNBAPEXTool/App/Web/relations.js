/* Static references only. BL sites are decoded from bytes; caller boundaries are metadata intervals. */
(function(root){
'use strict';
const LIMIT=100000;
function binary(bytes,model){
 const edges=[],references=[],stringTargets=new Map((model.stringFindings||[]).filter(f=>f.va!==null&&f.section!=='ngoài section đã biết').map(f=>[f.va.toString(),f])),stats={scannedInstructions:0,directBL:0,resolvedBL:0,stored:0,truncated:false,skipped:model.encrypted?'Vùng mã còn mã hóa':''};
 if(model.encrypted)return {edges,references,stats};
 const targets=new Map(model.rows.map(r=>[r.va.toString(),r]));
 for(const section of model.sections){
  if(!(section.name==='__text'||(section.flags&0x80000400)!==0)||['__stubs','__auth_stubs','__stub_helper'].includes(section.name)||section.va%4n||!section.size)continue;
  const range=model.map(section.va),end=model.map(section.va+section.size-1n);
  if(!range||!end||end.fileOffset!==range.fileOffset+section.size-1n)continue;
  const offset=Number(range.fileOffset),size=Number(section.size);if(offset<0||offset+size>bytes.length)continue;
  const functions=model.rows.filter(r=>r.va>=section.va&&r.va<section.va+section.size).map(r=>({va:r.va,relative:Number(r.va-section.va)}));let cursor=-1;
  for(let p=0;p+4<=size;p+=4){
   stats.scannedInstructions++;while(cursor+1<functions.length&&functions[cursor+1].relative<=p)cursor++;
   const q=offset+p,w=(bytes[q]|bytes[q+1]<<8|bytes[q+2]<<16|bytes[q+3]<<24)>>>0;
   // Only ADR or an adjacent ADRP + 64-bit ADD immediate constructing an exact stored string address.
   if(((w>>>0)&0x1f000000)===0x10000000&&(w&31)!==31){
    let imm=(((w>>>5)&0x7ffff)*4)+((w>>>29)&3);if(imm&0x100000)imm-=0x200000;
    const siteVA=section.va+BigInt(p);let address=null,method='ADR',endSite=siteVA;
    if((w>>>31)===0)address=siteVA+BigInt(imm);
    else if(p+8<=size){const a=(bytes[q+4]|bytes[q+5]<<8|bytes[q+6]<<16|bytes[q+7]<<24)>>>0;
     if(((a&0xff800000)>>>0)===0x91000000&&((a>>>5)&31)===(w&31)&&(a&31)!==31){address=(siteVA&~4095n)+BigInt(imm)*4096n+BigInt((a>>>10)&4095)*((a>>>22)&1?4096n:1n);method='ADRP + ADD kề nhau';endSite=siteVA+4n;}
    }
    const string=address===null?null:stringTargets.get(address.toString());
    if(string&&references.length<20000)references.push({callerVA:cursor>=0?functions[cursor].va:null,siteVA,endSite,stringVA:address,stringFileOffset:string.fileOffset,text:string.name,evidence:string.evidence,method,note:'Mẫu dựng đúng địa chỉ chuỗi; chưa chứng minh dữ liệu đi vào điều kiện bảo mật. Hàm chứa lệnh suy theo khoảng metadata.'});
    else if(string)stats.referencesTruncated=true;
   }
   if(w>>>26!==0x25)continue;stats.directBL++;
   let imm=w&0x03ffffff;if(imm&0x02000000)imm-=0x04000000;
   const siteVA=section.va+BigInt(p),targetVA=siteVA+BigInt(imm*4);if(!targets.has(targetVA.toString()))continue;stats.resolvedBL++;
   if(edges.length>=LIMIT){stats.truncated=true;continue;}
   edges.push({callerVA:cursor>=0?functions[cursor].va:null,siteVA,targetVA,source:'ARM64 BL',note:'Điểm gọi giải mã trực tiếp; hàm chứa điểm gọi suy theo khoảng giữa các mốc metadata, chưa xác minh ranh giới.'});
  }
 }
 stats.stored=edges.length;stats.stringReferences=references.length;return {edges,references,stats};
}
function combine(rows,model){
 const edges=[...(model?.callGraph?.edges||[])],names=new Map(),seen=new Set();let truncated=!!model?.callGraph?.stats.truncated;let byVA;
 for(const row of rows){for(const n of [row.name,'sub_'+row.va.toString(16).toUpperCase(),'FUN_'+row.va.toString(16)]){if(!names.has(n))names.set(n,row);else if(names.get(n)?.va!==row.va)names.set(n,null);}}
 for(const row of rows)for(const name of row.calls||[]){let target=names.get(name);
  if(!target){const m=/^(?:sub_|FUN_)([0-9a-f]+)$/i.exec(name);if(m)target=rowsByVA().get(BigInt('0x'+m[1]).toString());}
  if(!target)continue;const key=row.va+'>'+target.va;if(seen.has(key))continue;seen.add(key);
  if(edges.length>=LIMIT){truncated=true;continue;}
  edges.push({callerVA:row.va,targetVA:target.va,siteVA:null,source:'Dump C',note:'Quan hệ tên lời gọi trong dump C; địa chỉ nhãn và phiên bản chưa xác minh.'});
 }
 function rowsByVA(){return byVA||(byVA=new Map(rows.map(r=>[r.va.toString(),r])));}
 return {edges,truncated};
}
function related(rows,model,seeds,options={}){
 const depth=Math.max(1,Math.min(3,Number(options.depth)||1)),direction=options.direction||'both',maxDegree=Math.max(0,Number(options.maxDegree)||0),graph=combine(rows,model),byVA=new Map(rows.map((r,i)=>[r.va.toString(),{row:r,index:i}])),adj=new Map(),degree=new Map(),found=new Map(),distance=new Map(),queue=[],skippedHubs=new Set();let limited=false;
 function connect(from,to,edge,direction){if(from===null)return;const key=from.toString();if(!adj.has(key))adj.set(key,[]);adj.get(key).push({va:to,edge,direction});}
 const degrees=new Map();for(const e of graph.edges){if(e.callerVA===null)continue;for(const [from,to] of [[e.callerVA,e.targetVA],[e.targetVA,e.callerVA]]){const key=from.toString();if(!degrees.has(key))degrees.set(key,new Set());degrees.get(key).add(to.toString());}
  if(direction==='both'||direction==='outgoing')connect(e.callerVA,e.targetVA,e,'Được hàm trước gọi');if(direction==='both'||direction==='incoming')connect(e.targetVA,e.callerVA,e,'Gọi hàm trước');
 }
 for(const [key,set] of degrees)degree.set(key,set.size);
 for(const key of seeds){if(byVA.has(key)){distance.set(key,0);queue.push({va:BigInt(key),root:BigInt(key),steps:[],depth:0});}}
 for(let q=0;q<queue.length;q++){const current=queue[q],key=current.va.toString();if(current.depth>=depth)continue;if(current.depth>0&&maxDegree&&degree.get(key)>maxDegree){skippedHubs.add(key);continue;}
  for(const link of adj.get(key)||[]){if(link.va===null||!byVA.has(link.va.toString())||seeds.has(link.va.toString()))continue;const to=link.va.toString(),nextDepth=current.depth+1,previous=distance.get(to);if(previous!==undefined&&previous<nextDepth)continue;
   if(!found.has(to)){if(found.size>=5000){limited=true;continue;}found.set(to,{...byVA.get(to),relations:[],hop:nextDepth,degree:degree.get(to)||0});}
   const steps=[...current.steps,{fromVA:current.va,toVA:link.va,callerVA:link.edge.callerVA,targetVA:link.edge.targetVA,siteVA:link.edge.siteVA,source:link.edge.source,note:link.edge.note}];const item=found.get(to);
   if(item.relations.length<16)item.relations.push({anchorVA:current.root,direction:nextDepth===1?link.direction:'Liên kết '+nextDepth+' bước',siteVA:link.edge.siteVA,source:link.edge.source,note:link.edge.note,hop:nextDepth,steps});
   if(previous===undefined){distance.set(to,nextDepth);queue.push({va:link.va,root:current.root,steps,depth:nextDepth});}
  }
 }
 return {items:[...found.values()],stats:{edges:graph.edges.length,truncated:graph.truncated,relatedLimitReached:limited,depth,direction,maxDegree,skippedHubs:skippedHubs.size},degree};
}
const api={binary,combine,related};root.OffsetRelations=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
