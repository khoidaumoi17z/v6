/* Native iOS adapters, bounded C previews and 100 MiB file limit. */
(function(){
'use strict';
const handler=window.webkit?.messageHandlers?.iosDesk;
if(!handler)return;
let incoming=null;
function send(payload){handler.postMessage(payload);}
for(const [id,kind] of [['binary','binary'],['dump','dump']]){
 document.getElementById(id).onclick=()=>send({action:'pick',kind});
}
document.getElementById('diagnostics').onclick=()=>send({action:'diagnostics'});
document.getElementById('localFiles').onclick=()=>send({action:'localFiles'});
for(const id of ['reset','demo'])document.getElementById(id).addEventListener('click',()=>send({action:'reset'}));
function busy(value){window.DeskBusy=!!value;for(const id of ['binary','dump','localFiles','reset','demo'])document.getElementById(id).disabled=!!value;window.setDumpBusy(!!value);window.setAnalysisBusy(!!value);
 document.getElementById('csv').disabled=document.getElementById('json').disabled=!!value||!rows.length;
 document.getElementById('generate').disabled=!!value||!selected||!model||selected.rva==null||demoMode;
 document.getElementById('save').disabled=document.getElementById('copy').disabled=!!value||!document.getElementById('out').value;}
// Replace the global download adapter used by all three exporters.
window.download=function(name,text,type){send({action:'export',name,text,type});};
document.getElementById('copy').onclick=()=>send({action:'copy',text:document.getElementById('out').value});
for(const link of document.querySelectorAll('a[href^="https://"]')){
 link.addEventListener('click',event=>{event.preventDefault();send({action:'openURL',url:link.href});});
}
window.OffsetIOS={
 begin(kind,name,size){
  if(!['binary','dump'].includes(kind)||!Number.isSafeInteger(size)||size<0)throw Error('Dữ liệu nhập không hợp lệ.');
  const limit=OffsetEvidence.MAX_FILE_BYTES;
  if(size>limit)throw Error('File vượt giới hạn của tool.');
  incoming={kind,name,size,position:0};
  if(kind==='binary'){incoming.bytes=new Uint8Array(size);incoming.scanner=OffsetEvidence.stringScanner();}
  else {incoming.decoder=new TextDecoder('utf-8',{fatal:true});incoming.parser=OffsetDumpStream.create();}
  report('Đang nhập '+name+'…');
 },
 append(base64){
  if(!incoming)throw Error('Chưa bắt đầu nhập file.');
  const chunk=atob(base64);
  if(incoming.position+chunk.length>incoming.size)throw Error('Dữ liệu vượt kích thước file.');
  const bytes=new Uint8Array(chunk.length);for(let i=0;i<chunk.length;i++)bytes[i]=chunk.charCodeAt(i);
  if(incoming.kind==='binary'){incoming.bytes.set(bytes,incoming.position);incoming.scanner.push(bytes,incoming.position);}
  else incoming.parser.push(incoming.decoder.decode(bytes,{stream:true}));
  incoming.position+=chunk.length;
  report('Đang nhập '+incoming.name+' · '+Math.floor(incoming.position/Math.max(1,incoming.size)*100)+'%');
 },
 finish(){
  if(!incoming||incoming.position!==incoming.size)throw Error('File nhập chưa đầy đủ.');
  const current=incoming;incoming=null;
  if(current.kind==='binary'){
   const next=OffsetDesk.parseMachO(current.bytes.buffer);
   const scan=current.scanner.finish();next.stringFindings=scan.hits.map(hit=>OffsetEvidence.mapString(hit,next));next.stringScanStats={total:scan.total,truncated:scan.truncated,limit:scan.limit};
   next.callGraph=OffsetRelations.binary(current.bytes,next);
   current.bytes=null;
   if(model){dumpRows=[];dumpName='';window.dumpImportStats=null;}
   model=next;sourceName=current.name;demoMode=false;
   document.getElementById('image').value=current.name;
  }else{
   current.parser.push(current.decoder.decode());
   const result=current.parser.finish();
   dumpRows=result.rows;window.dumpImportStats=result.stats;dumpName=current.name;demoMode=false;
  }
  rebuild();busy(false);
  if(window.dumpImportStats?.truncatedPreviews)report(document.getElementById('status').textContent+'\nXem trước thân hàm đã rút gọn để tiết kiệm bộ nhớ; vẫn quét dấu hiệu trên toàn bộ nội dung đã đọc.');
 },
 cancel(message){incoming=null;busy(false);report(message||'Đã hủy nhập file.');},
 notify(message){report(message);},
 setImportBusy(value){busy(value);},
 setDumpBusy(value){busy(value);}
};
})();
